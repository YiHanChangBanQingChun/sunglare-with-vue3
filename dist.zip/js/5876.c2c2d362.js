"use strict";(self["webpackChunksun_glare_project"]=self["webpackChunksun_glare_project"]||[]).push([[5876],{33495:function(e,n,t){t.r(n),t.d(n,{CalciteAction:function(){return c},defineCustomElement:function(){return r}});var u=t(10374);
/*!
 * All material copyright ESRI, All Rights Reserved, unless otherwise specified.
 * See https://github.com/Esri/calcite-design-system/blob/main/LICENSE.md for details.
 * v1.11.0
 */const c=u.A,r=u.d}}]);
//# sourceMappingURL=5876.c2c2d362.js.map